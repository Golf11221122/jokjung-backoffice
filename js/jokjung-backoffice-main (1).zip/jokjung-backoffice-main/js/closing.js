import { supabase } from './supabase.js'
import { requireBackoffice, setupShell, money, number, esc } from './auth.js'

let rows=[]
let counts=[]
let detail=null

function periodText(v){return({daily:'รายวัน',weekly:'รายสัปดาห์',monthly:'รายเดือน',custom:'กำหนดเอง'})[v]||v}
function dateValue(d){return`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function setDates(type){
    const n=new Date();let a=new Date(n.getFullYear(),n.getMonth(),n.getDate())
    if(type==='weekly'){const day=(n.getDay()+6)%7;a=new Date(n.getFullYear(),n.getMonth(),n.getDate()-day)}
    if(type==='monthly')a=new Date(n.getFullYear(),n.getMonth(),1)
    document.getElementById('dateFrom').value=dateValue(a);document.getElementById('dateTo').value=dateValue(n)
}
function msg(t=''){document.getElementById('message').textContent=t}
function nmsg(t=''){document.getElementById('newMessage').textContent=t}
function dmsg(t=''){document.getElementById('detailMessage').textContent=t}
function k(label,val,small='',cls=''){return`<article class="cost-kpi ${cls}"><span>${label}</span><strong>${val}</strong><small>${small}</small></article>`}

async function loadCounts(){
    const{data,error}=await supabase.rpc('backoffice_list_completed_counts_for_closing')
    if(error)return msg(error.message)
    counts=data||[]
    document.getElementById('countId').innerHTML='<option value="">-- เลือก Stock Count --</option>'+
        counts.map(x=>`<option value="${x.id}">${esc(x.count_no)} • ${esc(x.count_type)} • ${x.item_count} รายการ</option>`).join('')
}
async function load(){
    const{data,error}=await supabase.rpc('backoffice_list_inventory_closings')
    if(error)return msg(error.message)
    rows=data||[];renderList()
}
function renderList(){
    document.getElementById('list').innerHTML=rows.length?`<div class="table-wrap"><table><thead><tr>
    <th>เลขที่</th><th>รอบ</th><th>ช่วงเวลา</th><th>สถานะ</th><th class="num">ยอดขาย</th>
    <th class="num">Theo Cost%</th><th class="num">Actual Cost%</th><th class="num">Cost Gap</th>
    <th class="num">ขาด</th><th class="num">Coverage</th><th>จัดการ</th></tr></thead><tbody>
    ${rows.map(x=>`<tr><td><strong>${esc(x.closing_no)}</strong></td><td>${periodText(x.period_type)}</td>
    <td>${new Date(x.period_start).toLocaleDateString('th-TH')} - ${new Date(x.period_end).toLocaleDateString('th-TH')}</td>
    <td><span class="closing-status ${x.status}">${x.status==='closed'?'ปิดแล้ว':'Draft'}</span></td>
    <td class="num">${money(x.net_sales)}</td><td class="num">${Number(x.theoretical_cost_pct||0).toFixed(2)}%</td>
    <td class="num">${Number(x.actual_cost_pct||0).toFixed(2)}%</td>
    <td class="num ${Number(x.variance_cost_pct)>0?'loss':'gain'}">${Number(x.variance_cost_pct||0).toFixed(2)}%</td>
    <td class="num loss">${money(x.shortage_value)}</td><td class="num">${Number(x.coverage_pct||0).toFixed(0)}%</td>
    <td><button class="small-btn" data-open="${x.id}">ดูรายละเอียด</button></td></tr>`).join('')}
    </tbody></table></div>`:'<div class="empty">ยังไม่มีรอบปิด Stock</div>'
}
async function create(){
    const from=document.getElementById('dateFrom').value,to=document.getElementById('dateTo').value,cid=document.getElementById('countId').value
    if(!from||!to)return nmsg('กรุณาระบุวันที่')
    if(!cid)return nmsg('กรุณาเลือก Stock Count ที่เสร็จแล้ว')
    const{data,error}=await supabase.rpc('backoffice_create_inventory_closing',{
        p_period_type:document.getElementById('periodType').value,
        p_period_start:new Date(`${from}T00:00:00`).toISOString(),
        p_period_end:new Date(`${to}T23:59:59.999`).toISOString(),
        p_stock_count_id:cid,p_note:document.getElementById('note').value||null
    })
    if(error)return nmsg(error.message.includes('CLOSING_PERIOD_OVERLAPS')?'มีรอบที่ปิดแล้วทับช่วงเวลานี้':error.message)
    document.getElementById('newModal').classList.add('hidden');await load();await openDetail(data)
}
async function openDetail(id){
    const{data,error}=await supabase.rpc('backoffice_get_inventory_closing',{p_closing_id:id})
    if(error)return msg(error.message)
    detail=data
    document.getElementById('detailTitle').textContent=data.closing_no
    document.getElementById('detailPeriod').textContent=`${periodText(data.period_type)} • ${new Date(data.period_start).toLocaleString('th-TH')} - ${new Date(data.period_end).toLocaleString('th-TH')} • ${data.status==='closed'?'ปิดแล้ว':'Draft'}`
    renderDetail();document.getElementById('detailModal').classList.remove('hidden')
}
function renderDetail(){
    const d=detail
    document.getElementById('detailKpis').innerHTML=
        k('ยอดขายสุทธิ',money(d.net_sales))+
        k('Theoretical Cost',money(d.theoretical_cost),`${Number(d.theoretical_cost_pct).toFixed(2)}%`)+
        k('Actual Control Cost',money(d.actual_control_cost),`${Number(d.actual_cost_pct).toFixed(2)}%`,'cost-warn')+
        k('Cost Gap',`${Number(d.variance_cost_pct).toFixed(2)}%`,money(Number(d.actual_control_cost)-Number(d.theoretical_cost)),Number(d.variance_cost_pct)>0?'cost-danger':'cost-good')+
        k('Waste',money(d.waste_cost))+
        k('Production Yield Loss',money(d.production_yield_loss_value||0),'ต่ำกว่า Standard Yield',Number(d.production_yield_loss_value)>0?'cost-danger':'')+
        k('ของขาดไม่ทราบสาเหตุ',money(d.shortage_value),`ของเกิน ${money(d.overage_value)}`,'cost-danger')+
        k('Stock ยกมา',money(d.opening_value))+
        k('รับเข้า',money(d.purchase_value))+
        k('Expected Closing',money(d.expected_closing_value))+
        k('Actual/Estimated Closing',money(d.actual_closing_value))+
        k('Coverage',`${Number(d.coverage_pct).toFixed(1)}%`,`${d.counted_items}/${d.total_items} รายการ`)

    document.getElementById('categoryCards').innerHTML=(d.categories||[]).map(c=>`<article class="category-cost-card"><h4>${esc(c.category_name)}</h4>
    <div class="category-cost-row"><span>Theoretical</span><strong>${money(c.theoretical_cost)}</strong></div>
    <div class="category-cost-row"><span>Waste</span><strong>${money(c.waste_cost)}</strong></div>
    <div class="category-cost-row"><span>ขาด</span><strong class="loss">${money(c.shortage_value)}</strong></div>
    <div class="category-cost-row"><span>เกิน</span><strong class="gain">${money(c.overage_value)}</strong></div>
    <div class="category-cost-row"><span>Actual Control</span><strong>${money(c.actual_control_cost)}</strong></div></article>`).join('')

    document.getElementById('itemTable').innerHTML=`<div class="table-wrap"><table class="raw-table"><thead><tr>
    <th>วัตถุดิบ</th><th>หมวด</th><th class="num">ยกมา</th><th class="num">ซื้อเข้า</th>
    <th class="num">Prod In</th><th class="num">Prod Out</th><th class="num">คืน</th><th class="num">ปรับ+</th>
    <th class="num">ขายใช้</th><th class="num">Waste</th><th class="num">ปรับ-</th><th class="num">ควรเหลือ</th>
    <th class="num">นับจริง</th><th class="num">ต่าง</th><th class="num">มูลค่าต่าง</th><th class="num">Cost/Unit</th>
    </tr></thead><tbody>${(d.items||[]).map(x=>`<tr>
    <td><strong>${esc(x.ingredient_name)}</strong><br><small>${esc(x.unit)}</small></td><td>${esc(x.category_name)}</td>
    <td class="num">${number(x.opening_qty)}</td><td class="num">${number(x.stock_in_qty)}</td>
    <td class="num">${number(x.production_in_qty||0)}</td><td class="num">${number(x.production_out_qty||0)}</td>
    <td class="num">${number(x.void_qty)}</td><td class="num">${number(x.adjust_in_qty)}</td>
    <td class="num">${number(x.sale_usage_qty)}</td><td class="num">${number(x.waste_qty)}</td>
    <td class="num">${number(x.adjust_out_qty)}</td><td class="num">${number(x.expected_qty)}</td>
    <td class="num">${x.actual_qty===null?'ยังไม่นับ':number(x.actual_qty)}</td>
    <td class="num ${Number(x.variance_qty)<0?'loss':Number(x.variance_qty)>0?'gain':''}">${x.variance_qty===null?'-':number(x.variance_qty)}</td>
    <td class="num ${Number(x.variance_value)<0?'loss':Number(x.variance_value)>0?'gain':''}">${x.variance_value===null?'-':money(x.variance_value)}</td>
    <td class="num">${money(x.unit_cost_snapshot)}</td></tr>`).join('')}</tbody></table></div>`

    document.getElementById('audit').innerHTML='<h4>Audit</h4>'+(d.audit||[]).map(a=>`<div class="audit-row"><strong>${esc(a.action)}</strong> • ${new Date(a.acted_at).toLocaleString('th-TH')} • ${esc(a.acted_by_name||'-')}<br><small>${esc(a.reason||'')}</small></div>`).join('')
    document.getElementById('detailActions').innerHTML=d.status==='draft'
        ?'<button class="outline-btn" id="refreshClosing">↻ คำนวณใหม่</button><button class="primary-btn" id="closeClosing">🔒 ยืนยันปิดรอบ</button>'
        :'<button class="outline-btn" id="reopenClosing">🔓 เปิดรอบใหม่ (Admin)</button>'
    bindActions()
}
function bindActions(){
    document.getElementById('refreshClosing')?.addEventListener('click',refreshClosing)
    document.getElementById('closeClosing')?.addEventListener('click',closeClosing)
    document.getElementById('reopenClosing')?.addEventListener('click',reopenClosing)
}
async function refreshClosing(){const{error}=await supabase.rpc('backoffice_refresh_inventory_closing',{p_closing_id:detail.id});if(error)return dmsg(error.message);await openDetail(detail.id);await load()}
async function closeClosing(){if(!confirm('ยืนยันปิดรอบ Stock? ระบบจะเก็บ Snapshot รวม Production'))return;const{error}=await supabase.rpc('backoffice_close_inventory_closing',{p_closing_id:detail.id});if(error)return dmsg(error.message);await openDetail(detail.id);await load()}
async function reopenClosing(){const r=prompt('เหตุผลในการเปิดรอบใหม่ (Admin เท่านั้น)');if(r===null)return;const{error}=await supabase.rpc('backoffice_reopen_inventory_closing',{p_closing_id:detail.id,p_reason:r});if(error)return dmsg(error.message.includes('ADMIN_REQUIRED')?'ต้องใช้สิทธิ์ Admin':error.message);await openDetail(detail.id);await load()}

document.getElementById('newBtn').onclick=()=>{setDates('daily');document.getElementById('periodType').value='daily';document.getElementById('note').value='';nmsg('');document.getElementById('newModal').classList.remove('hidden')}
document.getElementById('periodType').onchange=e=>setDates(e.target.value)
document.getElementById('closeNew').onclick=()=>document.getElementById('newModal').classList.add('hidden')
document.getElementById('createBtn').onclick=create
document.getElementById('closeDetail').onclick=()=>document.getElementById('detailModal').classList.add('hidden')
document.getElementById('list').onclick=e=>{const b=e.target.closest('[data-open]');if(b)openDetail(b.dataset.open)}

const ctx=await requireBackoffice()
if(ctx){setupShell(ctx,'closing');await loadCounts();await load()}
